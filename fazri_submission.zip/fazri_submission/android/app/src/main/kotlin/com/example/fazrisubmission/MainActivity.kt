package com.example.fazrisubmission

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
